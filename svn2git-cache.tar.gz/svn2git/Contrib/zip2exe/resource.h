//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by res.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON1                       102
#define IDC_ZIPFILE                     1000
#define IDC_BROWSE                      1001
#define IDC_ZIPINFO_SUMMARY             1002
#define IDC_ZIPINFO_FILES               1004
#define IDC_INSTPATH                    1005
#define IDC_DESCTEXT                    1006
#define IDC_OUTFILE                     1007
#define IDC_BROWSE2                     1008
#define IDC_INSTNAME                    1009
#define IDC_SZIPFRAME                   1010
#define IDC_OFRAME                      1011
#define IDC_INAMEST                     1012
#define IDC_DEPST                       1014
#define IDC_OEFST                       1015
#define IDC_OUTPUTTEXT                  1016
#define IDC_TEST                        1017
#define IDC_BACK                        1018
#define IDC_COMPILER                    1019
#define IDC_ZLIB                        1020
#define IDC_MODERNUI                    1021
#define IDC_COMPRESSOR                  1022
#define IDC_INTERFACE                   1023
#define IDC_BZIP2                       1024
#define IDC_CLASSICUI                   1025
#define IDC_INFO                        1026
#define IDC_NSISICON                    1027
#define IDC_LZMA                        1028
#define IDC_SOLID                       1029
#define IDC_UNICODE                     1030

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
